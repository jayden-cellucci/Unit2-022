#Plaintext Parameters
function BadFunction {
    param(
        [String]$Username = 'me',
        [String]$Password = 'password'
    )
    $Username
    $Password
}
