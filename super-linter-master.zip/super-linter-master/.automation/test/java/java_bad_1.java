class java_bad_1 // first letter of classname is not capitalized
{

    public static void main(String args[])
    {
        System.out.println("Hello, World");
    }
}
