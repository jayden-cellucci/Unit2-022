# Docker Test Cases

This folder holds the test cases for **Docker**.

## Additional Docs

Due to the nature of the naming of files, we have `2` subfolders in this directory.

- `good` is for working, and correct **Dockerfile**(s)
- `bad` is for invalid, and incorrect **Dockerfile**(s)

## Good Test Cases

- **Note:** They are linted utilizing the default linter rules.

## Bad Test Cases

- **Note:** They are linted utilizing the default linter rules.
