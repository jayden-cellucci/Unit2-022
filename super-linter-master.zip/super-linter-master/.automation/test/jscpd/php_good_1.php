<?php

echo "Hello World!", PHP_EOL;
