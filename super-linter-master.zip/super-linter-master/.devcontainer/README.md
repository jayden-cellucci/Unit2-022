# Devcontainer

This file specifies to vscode how to run the container

For format details, see [documentation](https://aka.ms/vscode-remote/devcontainer.json) or this file's [README](https://github.com/microsoft/vscode-dev-containers/tree/v0.123.0/containers/docker-existing-dockerfile)

context: Sets the run context to one level up instead of the .devcontainer folder.
dockerFile: Update the 'dockerFile' property if you aren't using the standard 'Dockerfile' filename.
settings: Set _default_ container specific settings.json values on container create.
extensions: Add the IDs of extensions you want installed when the container is created.
